bash
flutter create todo_app
cd todo_app
