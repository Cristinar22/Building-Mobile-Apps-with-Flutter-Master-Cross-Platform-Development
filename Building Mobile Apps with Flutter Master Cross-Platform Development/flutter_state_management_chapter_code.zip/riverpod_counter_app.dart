dependencies:
  flutter:
    sdk: flutter
  flutter_riverpod: ^2.0.0

import 'package:flutter_riverpod/flutter_riverpod.dart';

final counterProvider = StateProvider<int>((ref) => 0);

void increment(WidgetRef ref) {
  ref.read(counterProvider.notifier).state++;
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'counter_provider.dart';

void main() {
  runApp(ProviderScope(child: MyApp()));
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text('Riverpod Counter App')),
        body: CounterPage(),
      ),
    );
  }
}

class CounterPage extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final counter = ref.watch(counterProvider);

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            'Counter: $counter',
            style: TextStyle(fontSize: 24),
          ),
          ElevatedButton(
            onPressed: () => increment(ref),
            child: Text('Increment'),
          ),
        ],
      ),
    );
  }
}