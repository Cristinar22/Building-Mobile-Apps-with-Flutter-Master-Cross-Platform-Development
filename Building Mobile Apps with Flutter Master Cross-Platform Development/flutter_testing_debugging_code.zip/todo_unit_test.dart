test('addTask should add a task to the list', () {
  var appState = _TodoAppState();
  appState._addTask('Test Task');
  expect(appState._tasks, contains('Test Task'));
});
