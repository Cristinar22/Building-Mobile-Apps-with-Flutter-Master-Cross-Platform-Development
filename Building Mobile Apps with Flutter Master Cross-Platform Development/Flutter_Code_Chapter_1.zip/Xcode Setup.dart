1. Download Xcode from the Mac App Store.
2. Once installed, open Xcode and agree to the terms and conditions. It might ask you to install additional components—allow that to happen.
    