Stack(
  children: <Widget>[
    Container(color: Colors.blue, width: 300, height: 300),
    Positioned(
      top: 50,
      left: 50,
      child: Container(color: Colors.red, width: 100, height: 100),
    ),
  ],
)