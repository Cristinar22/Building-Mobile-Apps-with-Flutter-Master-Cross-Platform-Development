
class CustomInputWidget extends StatelessWidget {
  final TextEditingController controller;
  final String labelText;
  final void Function(String) onSubmitted;

  CustomInputWidget({
    required this.controller,
    required this.labelText,
    required this.onSubmitted,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextField(
          controller: controller,
          decoration: InputDecoration(labelText: labelText),
        ),
        ElevatedButton(
          onPressed: () {
            onSubmitted(controller.text);
          },
          child: Text('Submit'),
        ),
      ],
    );
  }
}
