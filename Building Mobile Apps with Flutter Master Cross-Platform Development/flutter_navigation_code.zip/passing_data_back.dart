
class SecondScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Second Screen')),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // Popping the screen and passing data back
            Navigator.pop(context, 'Data from Second Screen');
          },
          child: Text('Go Back with Data'),
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Home Screen')),
      body: Center(
        child: ElevatedButton(
          onPressed: () async {
            // Navigating to the second screen and awaiting the result
            final result = await Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => SecondScreen()),
            );
            // Handling the returned data
            print('Returned data: $result');
          },
          child: Text('Go to Second Screen'),
        ),
      ),
    );
  }
}
