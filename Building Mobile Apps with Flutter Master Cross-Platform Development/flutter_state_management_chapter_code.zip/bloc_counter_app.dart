dependencies:
  flutter:
    sdk: flutter
  flutter_bloc: ^8.0.0

import 'package:flutter_bloc/flutter_bloc.dart';

class CounterCubit extends Cubit<int> {
  CounterCubit() : super(0);

  void increment() => emit(state + 1);
  void decrement() => emit(state - 1);
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'counter_cubit.dart';

void main() {
  runApp(
    BlocProvider(
      create: (_) => CounterCubit(),
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text('Bloc Counter App')),
        body: CounterPage(),
      ),
    );
  }
}

class CounterPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          BlocBuilder<CounterCubit, int>(
            builder: (context, counter) {
              return Text(
                'Counter: $counter',
                style: TextStyle(fontSize: 24),
              );
            },
          ),
          ElevatedButton(
            onPressed: () {
              context.read<CounterCubit>().increment();
            },
            child: Text('Increment'),
          ),
          ElevatedButton(
            onPressed: () {
              context.read<CounterCubit>().decrement();
            },
            child: Text('Decrement'),
          ),
        ],
      ),
    );
  }
}