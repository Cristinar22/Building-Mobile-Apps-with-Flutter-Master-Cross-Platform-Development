import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:your_app/main.dart';

void main() {
  testWidgets('Button text should change when clicked', (WidgetTester tester) async {
    await tester.pumpWidget(MyApp());

    final buttonFinder = find.byType(ElevatedButton);

    expect(find.text('Click Me'), findsOneWidget);
    expect(find.text('Hello, Flutter!'), findsNothing);

    await tester.tap(buttonFinder);
    await tester.pump();

    expect(find.text('Click Me'), findsNothing);
    expect(find.text('Hello, Flutter!'), findsOneWidget);
  });
}
