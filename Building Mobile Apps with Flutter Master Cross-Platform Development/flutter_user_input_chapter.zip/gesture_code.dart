
GestureDetector(
  onTap: () {
    print('Tapped!');
  },
  child: Container(
    color: Colors.blue,
    height: 100,
    width: 100,
    child: Center(child: Text('Tap Me')),
  ),
)
