testWidgets('TodoApp displays tasks and adds new tasks', (WidgetTester tester) async {
  await tester.pumpWidget(MaterialApp(home: TodoApp()));

  expect(find.text('New Task'), findsNothing);

  await tester.tap(find.byIcon(Icons.add));
  await tester.pump();

  expect(find.text('New Task'), findsOneWidget);
});
