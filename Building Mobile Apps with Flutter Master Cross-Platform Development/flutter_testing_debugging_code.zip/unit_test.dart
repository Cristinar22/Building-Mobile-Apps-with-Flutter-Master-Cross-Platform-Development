import 'package:test/test.dart';
import 'package:your_app/main.dart';

void main() {
  test('addNumbers should return the sum of two numbers', () {
    var result = addNumbers(2, 3);
    expect(result, 5);
  });
}
