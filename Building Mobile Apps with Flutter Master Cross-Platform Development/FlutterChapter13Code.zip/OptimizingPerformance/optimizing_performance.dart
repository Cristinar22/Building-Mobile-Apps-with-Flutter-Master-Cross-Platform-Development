dart
// Use const constructors for better performance
class MyWidget extends StatelessWidget {
  const MyWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const Text('This is a constant widget');
  }
}
