dart
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class PlatformSpecificWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    if (Theme.of(context).platform == TargetPlatform.iOS) {
      // iOS-specific widget
      return CupertinoButton(
        onPressed: () {},
        child: Text('iOS Button'),
      );
    } else {
      // Android-specific widget
      return ElevatedButton(
        onPressed: () {},
        child: Text('Android Button'),
      );
    }
  }
}
