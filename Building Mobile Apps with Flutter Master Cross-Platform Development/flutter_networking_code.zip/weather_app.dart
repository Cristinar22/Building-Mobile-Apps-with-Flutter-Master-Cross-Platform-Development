
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: WeatherScreen(),
    );
  }
}

class WeatherScreen extends StatefulWidget {
  @override
  _WeatherScreenState createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> {
  final TextEditingController _cityController = TextEditingController();
  String _weather = 'Enter a city and get the weather...';

  Future<void> _fetchWeather() async {
    Dio dio = Dio();
    String city = _cityController.text;
    String apiKey = 'YOUR_API_KEY';
    var url = 'https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey';

    try {
      final response = await dio.get(url);
      if (response.statusCode == 200) {
        final data = response.data;
        setState(() {
          _weather = 'Weather in $city: ${data['weather'][0]['description']}';
        });
      } else {
        setState(() {
          _weather = 'Error: ${response.statusCode}';
        });
      }
    } catch (e) {
      setState(() {
        _weather = 'Failed to load weather data.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Weather App')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _cityController,
              decoration: InputDecoration(labelText: 'Enter City'),
            ),
            ElevatedButton(
              onPressed: _fetchWeather,
              child: Text('Get Weather'),
            ),
            SizedBox(height: 20),
            Text(
              _weather,
              style: TextStyle(fontSize: 20),
            ),
          ],
        ),
      ),
    );
  }
}
