import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Complex Layout Example'),
        ),
        body: Column(
          children: [
            // Header
            Container(
              color: Colors.blue,
              height: 100,
              child: Center(
                child: Text(
                  'Header Section',
                  style: TextStyle(color: Colors.white, fontSize: 20),
                ),
              ),
            ),
            // Body
            Row(
              children: [
                Expanded(
                  child: Container(
                    color: Colors.green,
                    height: 200,
                    child: Center(
                      child: Text(
                        'Left Section',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    color: Colors.red,
                    height: 200,
                    child: Center(
                      child: Text(
                        'Right Section',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            // Footer
            Container(
              color: Colors.orange,
              height: 50,
              child: Center(
                child: Text(
                  'Footer Section',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
