
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert'; // For JSON decoding

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: WeatherScreen(),
    );
  }
}

class WeatherScreen extends StatefulWidget {
  @override
  _WeatherScreenState createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> {
  String _weather = 'Loading...';

  // Fetch weather data from the API
  Future<void> fetchWeather() async {
    // Replace with a real API key
    String apiKey = 'YOUR_API_KEY';
    String city = 'London';
    var url = Uri.parse('https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey');
    
    try {
      final response = await http.get(url);
      
      if (response.statusCode == 200) {
        // If the server returns a 200 OK response, parse the JSON
        final data = json.decode(response.body);
        setState(() {
          _weather = 'Weather in $city: ${data['weather'][0]['description']}';
        });
      } else {
        // If the server doesn't return a 200 OK response, throw an error
        setState(() {
          _weather = 'Error: ${response.statusCode}';
        });
      }
    } catch (e) {
      setState(() {
        _weather = 'Failed to load weather data.';
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchWeather();  // Fetch weather data when the app starts
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Weather App')),
      body: Center(
        child: Text(_weather),
      ),
    );
  }
}
