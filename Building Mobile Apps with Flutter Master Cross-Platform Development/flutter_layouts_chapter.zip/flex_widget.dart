Flex(
  direction: Axis.horizontal, // Use Axis.vertical for a column
  children: <Widget>[
    Expanded(
      child: Container(color: Colors.blue, height: 100),
    ),
    Expanded(
      child: Container(color: Colors.green, height: 100),
    ),
  ],
)