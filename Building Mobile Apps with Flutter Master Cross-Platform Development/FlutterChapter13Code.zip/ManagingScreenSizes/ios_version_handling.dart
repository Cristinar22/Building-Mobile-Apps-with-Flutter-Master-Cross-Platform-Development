dart
import 'package:platform/platform.dart';

if (localPlatform.isIOS && localPlatform.operatingSystemVersion.compareTo("14.0") >= 0) {
  // Code for iOS 14 and above
} else {
  // Code for older iOS versions
}
