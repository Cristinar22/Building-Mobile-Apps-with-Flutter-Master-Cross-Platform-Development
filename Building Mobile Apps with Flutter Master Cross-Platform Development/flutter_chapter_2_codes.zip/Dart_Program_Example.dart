void main() {
  print('Hello, Flutter!');
  int sum = addNumbers(5, 3);
  print('The sum is: $sum');
}

int addNumbers(int a, int b) {
  return a + b;
}