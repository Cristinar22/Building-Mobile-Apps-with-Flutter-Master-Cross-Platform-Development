import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Shared Preferences Demo',
      home: ThemePreferenceScreen(),
    );
  }
}

class ThemePreferenceScreen extends StatefulWidget {
  @override
  _ThemePreferenceScreenState createState() => _ThemePreferenceScreenState();
}

class _ThemePreferenceScreenState extends State<ThemePreferenceScreen> {
  bool _isDarkTheme = false;

  // Load the theme preference
  Future<void> _loadThemePreference() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isDarkTheme = prefs.getBool('isDarkTheme') ?? false;
    });
  }

  // Save the theme preference
  Future<void> _saveThemePreference(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setBool('isDarkTheme', value);
  }

  @override
  void initState() {
    super.initState();
    _loadThemePreference();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Shared Preferences Example')),
      body: Center(
        child: SwitchListTile(
          title: Text('Dark Theme'),
          value: _isDarkTheme,
          onChanged: (bool value) {
            setState(() {
              _isDarkTheme = value;
              _saveThemePreference(value);
            });
          },
        ),
      ),
    );
  }
}
