import 'package:hive/hive.dart';

void main() async {
  await Hive.initFlutter();
  var box = await Hive.openBox('notesBox');

  // Adding a note
  box.put('note1', 'This is a note');

  // Retrieving a note
  var note = box.get('note1');
  print(note);
}
