dart
import 'package:permission_handler/permission_handler.dart';

void requestPermission() async {
  if (await Permission.camera.request().isGranted) {
    // Permission granted
  }
}
