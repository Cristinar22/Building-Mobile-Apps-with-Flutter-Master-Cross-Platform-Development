dart
import 'package:flutter/material.dart';

class ResponsiveLayout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Get the screen size
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    if (screenWidth > 600) {
      // Larger screens (like tablets)
      return GridView.count(
        crossAxisCount: 3,
        children: List.generate(20, (index) {
          return Card(child: Center(child: Text('Item $index')));
        }),
      );
    } else {
      // Smaller screens (like phones)
      return ListView.builder(
        itemCount: 20,
        itemBuilder: (context, index) {
          return ListTile(title: Text('Item $index'));
        },
      );
    }
  }
}
