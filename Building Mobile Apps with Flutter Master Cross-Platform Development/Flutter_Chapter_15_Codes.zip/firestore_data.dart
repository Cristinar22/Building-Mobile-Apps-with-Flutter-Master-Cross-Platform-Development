
import 'package:cloud_firestore/cloud_firestore.dart';

void addData() async {
  await FirebaseFirestore.instance.collection('users').add({
    'name': 'John Doe',
    'email': 'john.doe@example.com',
  });
  print('Data added!');
}
