GridView.count(
  crossAxisCount: 2,
  children: <Widget>[
    Card(color: Colors.red),
    Card(color: Colors.blue),
    Card(color: Colors.green),
    Card(color: Colors.orange),
  ],
)