LayoutBuilder(
  builder: (context, constraints) {
    return Container(
      width: constraints.maxWidth * 0.5,
      height: 200,
      color: Colors.blue,
    );
  },
)