
import 'package:flutter/material.dart';

class MyPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    Paint paint = Paint()
      ..color = Colors.blue
      ..style = PaintingStyle.fill;

    // Drawing a circle
    canvas.drawCircle(Offset(size.width / 2, size.height / 2), 100, paint);

    // Drawing a line
    paint.color = Colors.red;
    paint.strokeWidth = 5;
    canvas.drawLine(Offset(0, 0), Offset(size.width, size.height), paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return false; // No need to repaint unless the widget changes.
  }
}
