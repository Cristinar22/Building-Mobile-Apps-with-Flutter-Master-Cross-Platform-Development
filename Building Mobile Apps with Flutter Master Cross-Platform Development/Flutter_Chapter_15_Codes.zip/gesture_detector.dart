
import 'package:flutter/material.dart';

class GestureExample extends StatefulWidget {
  @override
  _GestureExampleState createState() => _GestureExampleState();
}

class _GestureExampleState extends State<GestureExample> {
  Color _circleColor = Colors.blue;

  void _changeColor() {
    setState(() {
      _circleColor = _circleColor == Colors.blue ? Colors.green : Colors.blue;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Gesture Detector Example")),
      body: Center(
        child: GestureDetector(
          onTap: _changeColor, // Detects tap gesture
          child: Container(
            width: 200,
            height: 200,
            decoration: BoxDecoration(
              color: _circleColor,
              shape: BoxShape.circle,
            ),
          ),
        ),
      ),
    );
  }
}
