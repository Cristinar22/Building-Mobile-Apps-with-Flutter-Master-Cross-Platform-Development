
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: WeatherScreen(),
    );
  }
}

class WeatherScreen extends StatefulWidget {
  @override
  _WeatherScreenState createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> {
  String _weather = 'Loading...';

  // Fetch weather data using Dio
  Future<void> fetchWeather() async {
    Dio dio = Dio();
    String apiKey = 'YOUR_API_KEY';
    String city = 'London';
    var url = 'https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey';

    try {
      final response = await dio.get(url);

      if (response.statusCode == 200) {
        final data = response.data;
        setState(() {
          _weather = 'Weather in $city: ${data['weather'][0]['description']}';
        });
      } else {
        setState(() {
          _weather = 'Error: ${response.statusCode}';
        });
      }
    } catch (e) {
      setState(() {
        _weather = 'Failed to load weather data.';
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchWeather();  // Fetch weather data when the app starts
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Weather App')),
      body: Center(
        child: Text(_weather),
      ),
    );
  }
}
